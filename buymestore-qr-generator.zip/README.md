# 🔗 QR Code Generator Pro

> **Professional QR Code Generator** with real-time customization, multiple export options, and modern UI design. Perfect for businesses, developers, and personal use.

[![Live Demo](https://img.shields.io/badge/🌐_Live_Demo-buymestore.com-blue?style=for-the-badge)](https://buymestore.com)
[![GitHub](https://img.shields.io/badge/GitHub-Repository-black?style=for-the-badge&logo=github)](https://github.com/yourusername/buymestore-qr-generator)
[![Vercel](https://img.shields.io/badge/Deployed_on-Vercel-black?style=for-the-badge&logo=vercel)](https://vercel.com)

## ✨ Features

- 🎨 **Real-time QR Code Generation** - Instant preview as you type
- 🌈 **Full Color Customization** - Foreground and background color pickers
- 📏 **Multiple Size Options** - From 200x200 to 1000x1000 pixels
- 💾 **Instant Download** - High-quality PNG export
- 📱 **Fully Responsive** - Works perfectly on all devices
- 🌙 **Modern Dark UI** - Professional design with smooth animations
- ⚡ **Lightning Fast** - No server required, runs entirely in browser
- 🔧 **Developer Friendly** - Clean, modular JavaScript code

## 🚀 Live Demo

**Try it now:** [buymestore.com](https://buymestore.com)

## 📸 Screenshots

### Desktop View
- Clean, professional interface
- Real-time QR code preview
- Intuitive color and size controls

### Mobile View  
- Fully responsive design
- Touch-friendly controls
- Optimized for mobile usage

## 🛠️ Technologies Used

- **HTML5** - Semantic structure
- **CSS3** - Modern styling with animations
- **Vanilla JavaScript** - Clean, efficient code
- **QRCode.js** - Reliable QR generation library
- **Responsive Design** - Mobile-first approach

## 📦 Installation

### Option 1: Direct Download
```bash
# Download the zip file
# Extract and open index.html in browser
```

### Option 2: Clone Repository
```bash
git clone https://github.com/yourusername/buymestore-qr-generator.git
cd buymestore-qr-generator
# Open index.html in your browser
```

### Option 3: Deploy to Vercel
```bash
# Drag and drop the project folder to vercel.com
# Instant deployment with custom domain support
```

## 🎯 Use Cases

- **Business Cards** - Add QR codes to contact information
- **Marketing** - Link to websites, social media, promotions
- **Events** - Share event details, tickets, location info
- **Restaurants** - Digital menus, contact-free ordering
- **Developers** - API endpoints, documentation links
- **Personal** - WiFi passwords, contact sharing

## 🔧 Customization

The generator supports extensive customization:

- **Colors**: Any hex color for foreground and background
- **Sizes**: 200px to 1000px dimensions
- **Content**: URLs, text, phone numbers, email addresses
- **Export**: High-quality PNG format

## 📁 Project Structure

```
buymestore-qr-generator/
├── index.html          # Main application
├── styles.css          # Modern CSS styling
├── script.js           # Core JavaScript functionality
├── qrcode.min.js       # QR generation library
├── vercel.json         # Deployment configuration
├── package.json        # Project metadata
├── working-version.html # Simplified test version
└── README.md           # Documentation
```

## 🌐 Deployment

### Vercel (Recommended)
1. Drag project folder to [vercel.com](https://vercel.com)
2. Connect custom domain
3. Automatic HTTPS and global CDN

### GitHub Pages
1. Push to GitHub repository
2. Enable Pages in repository settings
3. Configure custom domain

### Netlify
1. Drag folder to [netlify.com](https://netlify.com)
2. Instant deployment
3. Custom domain configuration

## 🚀 Performance

- **Lightweight**: < 50KB total size
- **Fast Loading**: Optimized assets
- **No Dependencies**: Self-contained application
- **Cross-Browser**: Works on all modern browsers
- **Mobile Optimized**: 60fps animations

## 🤝 Contributing

Contributions are welcome! Please feel free to submit issues and pull requests.

1. Fork the repository
2. Create your feature branch
3. Commit your changes
4. Push to the branch
5. Open a Pull Request

## 📄 License

This project is open source and available under the [MIT License](LICENSE).

## 🔗 Links

- **Live Demo**: [buymestore.com](https://buymestore.com)
- **GitHub**: [Repository](https://github.com/yourusername/buymestore-qr-generator)
- **Issues**: [Bug Reports](https://github.com/yourusername/buymestore-qr-generator/issues)

## 💡 Future Enhancements

- [ ] Batch QR code generation
- [ ] Custom logo embedding
- [ ] SVG export option
- [ ] QR code scanning feature
- [ ] Analytics tracking
- [ ] API integration

---

**Built with ❤️ for the developer community**

*Need a QR code? Generate one instantly at [buymestore.com](https://buymestore.com)* 