// QR Code Generator - Main JavaScript File
class QRCodeGenerator {
    constructor() {
        this.initializeElements();
        this.bindEvents();
        this.loadFromLocalStorage();
    }

    initializeElements() {
        // Input elements
        this.textInput = document.getElementById('textInput');
        this.sizeSelect = document.getElementById('sizeSelect');
        this.errorLevelSelect = document.getElementById('errorLevel');
        this.foregroundColorInput = document.getElementById('foregroundColor');
        this.backgroundColorInput = document.getElementById('backgroundColor');
        
        // Button elements
        this.generateBtn = document.getElementById('generateBtn');
        this.clearBtn = document.getElementById('clearBtn');
        this.downloadBtn = document.getElementById('downloadBtn');
        
        // Display elements
        this.qrContainer = document.getElementById('qrContainer');
        this.downloadSection = document.getElementById('downloadSection');
        this.qrInfo = document.getElementById('qrInfo');
        
        // Color value displays
        this.foregroundColorValue = this.foregroundColorInput.nextElementSibling;
        this.backgroundColorValue = this.backgroundColorInput.nextElementSibling;
        
        // Current QR code data
        this.currentQRData = null;
    }

    bindEvents() {
        console.log('Binding events...');
        
        // Debug: Check if elements exist
        if (!this.generateBtn) {
            console.error('Generate button not found!');
            return;
        }
        if (!this.textInput) {
            console.error('Text input not found!');
            return;
        }
        
        console.log('All elements found, binding events...');
        
        // Generate button
        this.generateBtn.addEventListener('click', () => {
            console.log('Generate button clicked!');
            this.generateQRCode();
        });
        
        // Clear button
        this.clearBtn.addEventListener('click', () => this.clearAll());
        
        // Download button
        this.downloadBtn.addEventListener('click', () => this.downloadQRCode());
        
        // Real-time color value updates
        this.foregroundColorInput.addEventListener('input', (e) => {
            this.foregroundColorValue.textContent = e.target.value.toLowerCase();
            this.saveToLocalStorage();
        });
        
        this.backgroundColorInput.addEventListener('input', (e) => {
            this.backgroundColorValue.textContent = e.target.value.toLowerCase();
            this.saveToLocalStorage();
        });
        
        // Auto-generate on input change (with debounce)
        this.textInput.addEventListener('input', () => {
            this.debounce(() => {
                if (this.textInput.value.trim()) {
                    this.generateQRCode();
                }
                this.saveToLocalStorage();
            }, 500)();
        });
        
        // Save settings on change
        [this.sizeSelect, this.errorLevelSelect].forEach(element => {
            element.addEventListener('change', () => {
                if (this.textInput.value.trim()) {
                    this.generateQRCode();
                }
                this.saveToLocalStorage();
            });
        });
        
        // Keyboard shortcuts
        document.addEventListener('keydown', (e) => {
            if (e.ctrlKey || e.metaKey) {
                switch (e.key) {
                    case 'Enter':
                        e.preventDefault();
                        this.generateQRCode();
                        break;
                    case 'l':
                        e.preventDefault();
                        this.clearAll();
                        break;
                    case 's':
                        e.preventDefault();
                        if (this.currentQRData) {
                            this.downloadQRCode();
                        }
                        break;
                }
            }
        });
    }

    async generateQRCode() {
        console.log('generateQRCode called');
        const text = this.textInput.value.trim();
        console.log('Text to generate:', text);
        
        if (!text) {
            this.showError('Please enter some text or URL to generate QR code');
            return;
        }

        // Check if QRCode library is loaded
        if (typeof QRCode === 'undefined') {
            console.error('QRCode library not available');
            this.showError('QR Code library is still loading. Please wait a moment and try again.');
            return;
        }

        console.log('QRCode library available, starting generation...');

        try {
            this.setLoading(true);
            
            const size = parseInt(this.sizeSelect.value);
            const options = {
                text: text,
                width: size,
                height: size,
                colorDark: this.foregroundColorInput.value,
                colorLight: this.backgroundColorInput.value,
                correctLevel: QRCode.CorrectLevel[this.errorLevelSelect.value] || QRCode.CorrectLevel.M
            };
            
            console.log('Options:', options);

            // Clear previous QR code
            this.qrContainer.innerHTML = '';
            
            // Create container for QR code
            const qrContainer = document.createElement('div');
            qrContainer.style.display = 'flex';
            qrContainer.style.justifyContent = 'center';
            qrContainer.style.alignItems = 'center';
            
            // Generate QR code using qrcodejs library
            const qr = new QRCode(qrContainer, options);
            
            // Success callback with timeout to ensure rendering
            setTimeout(() => {
                console.log('QR generation callback called');
                this.setLoading(false);
                
                try {
                    // Find the generated element (canvas or image)
                    const generatedCanvas = qrContainer.querySelector('canvas');
                    const generatedImage = qrContainer.querySelector('img');
                    
                    let elementToUse = generatedCanvas || generatedImage;
                    
                    if (elementToUse) {
                        console.log('QR generation successful');
                        
                        // If it's an image, we need to create a canvas for download
                        if (generatedImage && !generatedCanvas) {
                            const canvas = document.createElement('canvas');
                            const ctx = canvas.getContext('2d');
                            canvas.width = size;
                            canvas.height = size;
                            
                            generatedImage.onload = () => {
                                ctx.drawImage(generatedImage, 0, 0, size, size);
                            };
                            
                            this.handleSuccessfulGeneration(canvas, text, options, qrContainer);
                        } else {
                            this.handleSuccessfulGeneration(elementToUse, text, options, qrContainer);
                        }
                    } else {
                        console.error('No QR code element found');
                        this.showError('Failed to generate QR code: No element created');
                    }
                } catch (error) {
                    console.error('Error in success callback:', error);
                    this.showError('Failed to process QR code: ' + error.message);
                }
            }, 200);

        } catch (error) {
            console.error('Error in generateQRCode:', error);
            this.showError('Failed to generate QR code: ' + error.message);
            this.setLoading(false);
        }
    }
    
    handleSuccessfulGeneration(element, text, options, qrContainer) {
        try {
            console.log('Adding QR code to container');
            
            // Add CSS class and styling to element
            element.className = 'qr-code-canvas';
            element.setAttribute('data-text', text);
            
            // Update container
            this.qrContainer.appendChild(qrContainer || element);
            this.qrContainer.classList.add('has-qr');
            
            console.log('QR code added successfully');
            
            // Store current QR data
            this.currentQRData = {
                text,
                canvas: element, // This might be canvas or image
                options
            };
            
            // Show download section
            this.downloadSection.style.display = 'block';
            this.updateQRInfo(text, options);
            
            // Update button state
            this.generateBtn.innerHTML = '<span class="btn-icon">✅</span>QR Code Generated';
            setTimeout(() => {
                this.generateBtn.innerHTML = '<span class="btn-icon">⚡</span>Generate QR Code';
            }, 2000);
            
        } catch (error) {
            console.error('Error in handleSuccessfulGeneration:', error);
            this.showError('Failed to display QR code: ' + error.message);
        }
    }

    clearAll() {
        // Clear input
        this.textInput.value = '';
        
        // Reset QR container
        this.qrContainer.innerHTML = `
            <div class="placeholder">
                <div class="placeholder-icon">📱</div>
                <p>Your QR code will appear here</p>
                <span class="placeholder-hint">Enter some text and click "Generate QR Code"</span>
            </div>
        `;
        this.qrContainer.classList.remove('has-qr');
        
        // Hide download section
        this.downloadSection.style.display = 'none';
        
        // Clear current data
        this.currentQRData = null;
        
        // Clear local storage
        localStorage.removeItem('qr-generator-data');
        
        // Focus on text input
        this.textInput.focus();
    }

    downloadQRCode() {
        if (!this.currentQRData) {
            this.showError('No QR code to download');
            return;
        }

        try {
            // Create download link
            const link = document.createElement('a');
            link.download = this.generateFilename(this.currentQRData.text);
            link.href = this.currentQRData.canvas.toDataURL('image/png');
            
            // Trigger download
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            
            // Update button temporarily
            const originalHTML = this.downloadBtn.innerHTML;
            this.downloadBtn.innerHTML = '<span class="btn-icon">✅</span>Downloaded!';
            setTimeout(() => {
                this.downloadBtn.innerHTML = originalHTML;
            }, 2000);
            
        } catch (error) {
            console.error('Error downloading QR code:', error);
            this.showError('Failed to download QR code');
        }
    }

    generateFilename(text) {
        const timestamp = new Date().toISOString().slice(0, 19).replace(/:/g, '-');
        const cleanText = text.slice(0, 30).replace(/[^a-zA-Z0-9]/g, '_');
        return `qrcode_${cleanText}_${timestamp}.png`;
    }

    updateQRInfo(text, options) {
        const info = [
            `Size: ${options.width}x${options.width}px`,
            `Error Correction: ${this.getErrorLevelName(options.errorCorrectionLevel)}`,
            `Characters: ${text.length}`,
            `Type: ${this.detectTextType(text)}`
        ].join(' | ');
        
        this.qrInfo.textContent = info;
    }

    getErrorLevelName(level) {
        const levels = {
            'L': 'Low',
            'M': 'Medium', 
            'Q': 'Quartile',
            'H': 'High'
        };
        return levels[level] || 'Medium';
    }

    detectTextType(text) {
        if (text.match(/^https?:\/\//)) return 'URL';
        if (text.match(/^mailto:/)) return 'Email';
        if (text.match(/^tel:/)) return 'Phone';
        if (text.match(/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i)) return 'Email';
        if (text.match(/^\+?[\d\s-()]+$/)) return 'Phone';
        return 'Text';
    }

    setLoading(isLoading) {
        if (isLoading) {
            this.generateBtn.disabled = true;
            this.generateBtn.innerHTML = '<div class="loading"></div>Generating...';
        } else {
            this.generateBtn.disabled = false;
        }
    }

    showError(message) {
        // Create error notification
        const errorDiv = document.createElement('div');
        errorDiv.className = 'error-notification';
        errorDiv.innerHTML = `
            <span class="error-icon">⚠️</span>
            <span class="error-message">${message}</span>
        `;
        
        // Add error styles
        errorDiv.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            background: var(--danger-color);
            color: white;
            padding: 1rem 1.5rem;
            border-radius: 8px;
            box-shadow: var(--shadow-lg);
            z-index: 1000;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            animation: slideInRight 0.3s ease-out;
        `;
        
        document.body.appendChild(errorDiv);
        
        // Remove after 5 seconds
        setTimeout(() => {
            errorDiv.style.animation = 'slideOutRight 0.3s ease-out';
            setTimeout(() => {
                if (errorDiv.parentNode) {
                    errorDiv.parentNode.removeChild(errorDiv);
                }
            }, 300);
        }, 5000);
    }

    debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }

    saveToLocalStorage() {
        const data = {
            text: this.textInput.value,
            size: this.sizeSelect.value,
            errorLevel: this.errorLevelSelect.value,
            foregroundColor: this.foregroundColorInput.value,
            backgroundColor: this.backgroundColorInput.value
        };
        
        localStorage.setItem('qr-generator-data', JSON.stringify(data));
    }

    loadFromLocalStorage() {
        try {
            const saved = localStorage.getItem('qr-generator-data');
            if (!saved) return;
            
            const data = JSON.parse(saved);
            
            // Restore values
            if (data.text) this.textInput.value = data.text;
            if (data.size) this.sizeSelect.value = data.size;
            if (data.errorLevel) this.errorLevelSelect.value = data.errorLevel;
            if (data.foregroundColor) {
                this.foregroundColorInput.value = data.foregroundColor;
                this.foregroundColorValue.textContent = data.foregroundColor;
            }
            if (data.backgroundColor) {
                this.backgroundColorInput.value = data.backgroundColor;
                this.backgroundColorValue.textContent = data.backgroundColor;
            }
            
            // Auto-generate if there's text
            if (data.text && data.text.trim()) {
                setTimeout(() => this.generateQRCode(), 100);
            }
            
        } catch (error) {
            console.error('Error loading from localStorage:', error);
        }
    }
}

// Add error notification animations to CSS dynamically
const style = document.createElement('style');
style.textContent = `
    @keyframes slideInRight {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOutRight {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(100%);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);

// Initialize the QR Code Generator when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    // Check if QRCode library is available, if not wait for it
    const initializeApp = () => {
        if (typeof QRCode !== 'undefined') {
            window.qrGenerator = new QRCodeGenerator();
        } else {
            // Wait a bit more for the library to load
            setTimeout(initializeApp, 100);
        }
    };
    
    initializeApp();
    
    // Add some example suggestions
    const examples = [
        'https://github.com/yourusername',
        'Check out my portfolio!',
        'mailto:hello@example.com',
        'tel:+1234567890',
        'Welcome to my GitHub page!'
    ];
    
    // Add placeholder cycling (optional enhancement)
    let currentExample = 0;
    const textInput = document.getElementById('textInput');
    const originalPlaceholder = textInput.placeholder;
    
    setInterval(() => {
        if (!textInput.value) {
            textInput.placeholder = examples[currentExample];
            currentExample = (currentExample + 1) % examples.length;
        }
    }, 3000);
    
    // Reset to original placeholder when user starts typing
    textInput.addEventListener('input', () => {
        if (textInput.value) {
            textInput.placeholder = originalPlaceholder;
        }
    });
});

// Service Worker Registration for PWA capabilities (optional)
if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        navigator.serviceWorker.register('/sw.js')
            .then(registration => {
                console.log('SW registered: ', registration);
            })
            .catch(registrationError => {
                console.log('SW registration failed: ', registrationError);
            });
    });
} 